﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class StudentLinkedList : MyLinkedList
    {
        private int FindLargestRecursivePart(MyLinkedListItem item)
        {
            if (item == null) return -1;
            int nextResult = FindLargestRecursivePart(item.Next);

            if (nextResult > item.Data) return nextResult;
            else return item.Data;
        }//FindLargestRecursivePart

        public int FindLargestRecursive()
        {
            return FindLargestRecursivePart(head);
        }//FindLargestRecursive()

        public int FindLargest()
        {
            //throw new NotImplementedException();
            int result = -1;
            MyLinkedListItem item = head;
            while (item != null)
            {
                if (item.Data > result) result = item.Data;
                item = item.Next;
            }
            return result;
        }
    }
}
