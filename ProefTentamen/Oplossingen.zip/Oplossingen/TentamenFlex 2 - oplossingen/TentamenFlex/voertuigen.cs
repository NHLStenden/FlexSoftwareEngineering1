﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class Voertuig
    {
        private String kenteken;
        double aankoopprijs;
        int aantalWielen;

        public Voertuig(int aantalWielen)
        {
            this.aantalWielen = aantalWielen;
        }

        public string Kenteken { get => kenteken; set => kenteken = value; }
    }//Voertuig

    class Motorfiets : Voertuig
    {
        public Motorfiets() : base(2)
        {

        }
    }//class Motorfiets

    class Auto : Voertuig
    {
        public Auto(): base(4)
        {

        }
    }// class Auto

    class Eigenaar
    {
        List<Voertuig> voertuigen;
        String naam;
        String adres;
        String BSN;

        public Eigenaar (String BSN, String naam)
        {
            this.BSN = BSN;
            this.naam = naam;
            this.voertuigen = new List<Voertuig>();
        }

        public int KoopVoertuig(Voertuig voertuig)
        {
            voertuigen.Add(voertuig);
            return voertuigen.Count;
        }
    }
}
