﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class Testcases
    {

        #region Vraag3a
        [Test]
        public void TestCountLetters()
        {
            Assert.AreEqual(3, CountLetters("abc"));
            Assert.AreEqual(3, CountLetters("a B c"));
            Assert.AreEqual(3, CountLetters("a B 4 c"));
            Assert.AreEqual(3, CountLetters("a 2B c"));
            Assert.AreEqual(0, CountLetters(""));
            Assert.AreEqual(0, CountLetters("11223"));
            Assert.AreEqual(0, CountLetters("@!#$%^"));
        }//TestCountLetters

        public static int CountLetters(string tekst)
        {
            int result = 0;
            foreach (char c in tekst)
            {
                if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) result++;
            }
            return result;

        }//CountLetters

        #endregion

        #region Vraag3b: 
        [Test]
        public void TestCountLettersRecursive()
        {
            Assert.AreEqual(3, CountLettersRecursive("abc"));
            Assert.AreEqual(3, CountLettersRecursive("a B c"));
            Assert.AreEqual(3, CountLettersRecursive("a B 4 c"));
            Assert.AreEqual(3, CountLettersRecursive("a 2B c"));
            Assert.AreEqual(0, CountLettersRecursive(""));
            Assert.AreEqual(0, CountLettersRecursive("11223"));
            Assert.AreEqual(0, CountLettersRecursive("@!#$%^"));
        }//TestCountLettersRecursive

        public static int CountLettersRecursive(string tekst)
        {
            if (String.IsNullOrEmpty(tekst)) return 0;

            int result = 0;
            if ((tekst[0] >= 'A' && tekst[0] <= 'Z') ||
                (tekst[0] >= 'a' && tekst[0] <= 'z')) result++;
            return result + CountLettersRecursive(tekst.Substring(1));
        }//CountLettersRecursive

        #endregion

        #region Vraag 3c: 
        [Test]
        public void TestFilterOdd()
        {
            int[] input       = { 1,2,3,4,5,6,7,8,9,10,11,12};
            CollectionAssert.AreEquivalent(new[] { 1, 3, 5, 7, 9, 11 }, FilterOdd(input));

            int[] input2 = { 10,9,8,7,6,5,4,3,2,1 };
            CollectionAssert.AreEquivalent(new[] { 9,7,5,3,1 }, FilterOdd(input2));

            int[] input3 = { 15,12,8,6,2,87,36,13};
            CollectionAssert.AreEquivalent(new[] { 15,87,13 }, FilterOdd(input3));
        }//TestFilterOdd()

        public static List<int> FilterOdd(int[] items)
        {
            List<int> result = new List<int>();
            foreach (int c in items) if (c % 2 == 1) result.Add(c);
            return result;
        }//FilterOdd()

        #endregion

        #region Vraag 4a
        [Test]
        public static void TestList1()
        {
            StudentLinkedList myList = new StudentLinkedList();
            myList.AddItem(1);
            myList.AddItem(6);
            myList.AddItem(3);
            myList.AddItem(4);
            myList.AddItem(2);
            myList.AddItem(5);

            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
        }//TestList1()
        #endregion

        #region Vraag 4b
        [Test]
        public static void TestList2()
        {
            StudentLinkedList myList = new StudentLinkedList();
            myList.AddItem(1);
            myList.AddItem(6);
            myList.AddItem(3);
            myList.AddItem(4);
            myList.AddItem(2);
            myList.AddItem(5);

            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());

        }//TestList2()
        #endregion
    }
}//Class Testcases


