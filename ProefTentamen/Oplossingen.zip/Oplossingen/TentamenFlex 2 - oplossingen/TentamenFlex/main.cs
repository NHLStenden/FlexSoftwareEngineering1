﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class Program
    {
        static void Main(string[] args)
        {
            Voertuig honda = new Motorfiets();
            Voertuig nissan350Z = new Motorfiets();
            Voertuig boot = new Voertuig(0);
            Voertuig vliegtuig = new Voertuig(0);
            honda.Kenteken = "42-http-200";
            nissan350Z.Kenteken = "443-https-2";

            Eigenaar MartinMolema = new Eigenaar("10104242", "Martin Molema");
            int aantalVoertuigen = MartinMolema.KoopVoertuig(honda);
            aantalVoertuigen     = MartinMolema.KoopVoertuig(nissan350Z);
            aantalVoertuigen     = MartinMolema.KoopVoertuig(boot);
            aantalVoertuigen     = MartinMolema.KoopVoertuig(vliegtuig);

            Console.WriteLine("Aantal voertuigen : {0}", aantalVoertuigen);

            Console.ReadLine();
        }
    }
}
