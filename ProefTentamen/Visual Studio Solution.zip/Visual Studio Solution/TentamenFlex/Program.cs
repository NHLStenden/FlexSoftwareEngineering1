﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class Program
    {

        #region Vraag3a
        [Test]
        public void TestCountLetters()
        {
            Assert.AreEqual(3, CountLetters("abc"));
            Assert.AreEqual(3, CountLetters("a B c"));
            Assert.AreEqual(3, CountLetters("a B 4 c"));
            Assert.AreEqual(3, CountLetters("a 2B c"));
            Assert.AreEqual(0, CountLetters(""));
            Assert.AreEqual(0, CountLetters("11223"));
            Assert.AreEqual(0, CountLetters("@!#$%^"));
        }//TestCountLetters

        public static int CountLetters(string tekst)
        {
            throw new NotImplementedException();
        }//CountLetters

        #endregion

        #region Vraag3b: 
        [Test]
        public void TestCountLettersRecursive()
        {
            Assert.AreEqual(3, CountLettersRecursive("abc"));
            Assert.AreEqual(3, CountLettersRecursive("a B c"));
            Assert.AreEqual(3, CountLettersRecursive("a B 4 c"));
            Assert.AreEqual(3, CountLettersRecursive("a 2B c"));
            Assert.AreEqual(0, CountLettersRecursive(""));
            Assert.AreEqual(0, CountLettersRecursive("11223"));
            Assert.AreEqual(0, CountLettersRecursive("@!#$%^"));
        }//TestCountLettersRecursive

        public static int CountLettersRecursive(string tekst)
        {
            throw new NotImplementedException();
        }//CountLettersRecursive

        #endregion

        #region Vraag 3c: 
        [Test]
        public void TestFilterOdd()
        {
            int [] input       = { 1,2,3,4,5,6,7,8,9,10,11,12};
            List<int> expectedOdd = new List<int> { 1,3,7,9,11};
            CollectionAssert.AreEquivalent(new[] { 1, 3, 5, 7, 9, 11 }, FilterOdd(input));
        }

        public static List<int> FilterOdd(int[] items)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Vraag 4a
        [Test]
        public static void TestList1()
        {
            StudentLinkedList myList = new StudentLinkedList();
            myList.AddItem(1);
            myList.AddItem(6);
            myList.AddItem(3);
            myList.AddItem(4);
            myList.AddItem(2);
            myList.AddItem(5);

            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
            Assert.AreEqual(6, myList.FindLargest());
        }
        #endregion

        #region Vraag 4b
        [Test]
        public static void TestList2()
        {
            StudentLinkedList myList = new StudentLinkedList();
            myList.AddItem(1);
            myList.AddItem(6);
            myList.AddItem(3);
            myList.AddItem(4);
            myList.AddItem(2);
            myList.AddItem(5);

            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());
            Assert.AreEqual(6, myList.FindLargestRecursive());

        }
        #endregion
    }


}


