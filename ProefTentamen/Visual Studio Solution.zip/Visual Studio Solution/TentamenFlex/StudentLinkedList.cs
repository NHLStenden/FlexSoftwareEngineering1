﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TentamenFlex
{
    class StudentLinkedList : MyLinkedList
    {
        public int FindLargestRecursive()
        {
            throw new NotImplementedException();
        }//FindLargest()

        public int FindLargest()
        {
            throw new NotImplementedException();
        }
    }
}
